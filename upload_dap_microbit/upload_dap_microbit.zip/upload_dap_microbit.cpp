//this code is modified from https://github.com/Ameba8195/Arduino/blob/master/ameba_tools_windows/tools/windows/src/upload_dap.cpp

#include <windows.h>
#include <iostream>
#include <sstream>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <string>
#include <cstdio>
#include <sys/stat.h>
#include <io.h>
#include <time.h>

using namespace std;

#define CHECK_DISK_RETRY 3

extern void upload_dap(string filepath_hex);

//https://blog.csdn.net/qiqzhang/article/details/83506886
time_t dir(string path, time_t from_seconds)
{
	time_t cur_seconds;
	if (from_seconds > 0) {
		cur_seconds = from_seconds;
	} else {
		cur_seconds = time(NULL);
	}
	//printf("%ld\n", cur_seconds);
	
    long hFile = 0;
    struct _finddata_t fileInfo;
    string pathName, exdName;
    if ((hFile = _findfirst(pathName.assign(path).append("\\*.hex").c_str(), &fileInfo)) == -1) {
        return from_seconds;
    }
    
    time_t maxseconds = 0;
    char maxname[256] = {0};
    do
    {
		if (fileInfo.attrib&_A_SUBDIR) {
			//folder, skip
		} else {
			//file
			//cout << fileInfo.name << endl;
			struct stat info;
			if (stat(fileInfo.name, &info) != 0) {
				//break; //not file
			} else {
				//cout << info.st_mtime << endl;
				if (info.st_mtime > maxseconds) {
					maxseconds = info.st_mtime;
					strcpy(maxname, fileInfo.name);
				}
			}
        }
    } while (_findnext(hFile, &fileInfo) == 0);
    _findclose(hFile);
    
    if (maxseconds > 0 && maxseconds > from_seconds) {
		cout << maxname << endl;
		upload_dap(maxname);
		return maxseconds;
    }
    
    return from_seconds;
}

bool isFileExist(string path) {
	bool ret = false;
	struct stat info;

	do {
		if (stat(path.c_str(), &info) != 0) {
			break;
		}

		ret = true;
	} while (0);

	return ret;
}

//https://github.com/amarao/flashnul/blob/685c6bf792f0de275f7cbb562c3324f521dd261c/src/detect.c
void list_logical_drives()
{
	DWORD 	req_space;
	DWORD 	res_space;
	char* 	buff;
	char* 	curr;
	int 	curr_len;

	req_space = GetLogicalDriveStrings( 0, NULL );
	if(!req_space || req_space>65535 ){
		printf("GetLogicalDriveStrings() fails\n");
		return;
	}


	buff=(char*)malloc(req_space+1);
	curr=buff;
	res_space = GetLogicalDriveStrings( req_space, buff );
	printf("\nAvaible logical disks:\n");
	while( *curr ){
		curr_len = strlen( curr );
		printf( "%s\t", curr );
		printf("\n");


		char VolumeName[256]; 
        GetVolumeInformation( curr,VolumeName,256,NULL,NULL,NULL,NULL,10); 
        printf( "%s\t", VolumeName );
        printf( "\n");
        

		curr+=curr_len+1;
	}
}

void upload_dap(string filepath_hex) {
	int i;
	bool mbed_disk_found = false;

	string cmd;
	vector<string> lines;
	vector<string>::iterator iter;

	stringstream ss;
	string disk_caption;
	string disk_volumename;
	string filepath;
	do {
		// 1. check if MBED disk driver exist
		for (i=0; i<CHECK_DISK_RETRY; i++) {
			mbed_disk_found = false;

            DWORD req_space = GetLogicalDriveStrings( 0, NULL );
            if(!req_space || req_space>65535 ){
                continue;
            }
            char *buff=(char*)malloc(req_space+1);
            char *curr=buff;
            DWORD res_space = GetLogicalDriveStrings( req_space, buff );
            while( *curr ){
                int curr_len = strlen( curr );
                char VolumeName[256] = {0}; 
                GetVolumeInformation( curr,VolumeName,256,NULL,NULL,NULL,NULL,10); 
                disk_caption = curr;
                disk_volumename = VolumeName;
                
                if (disk_volumename.compare("MICROBIT") == 0) {
					mbed_disk_found = true;
					break;
				}
                
                curr+=curr_len+1;
            }

			if (mbed_disk_found) {
				break;
			}
		}

		if (!mbed_disk_found) {
			cout << "ERR: Cannot find micro:bit on mbed driver! Please re-plug micro:bit." << endl;
			break;
		}

		// 2. check if MBED disk is accessable
		filepath = disk_caption + "\\MICROBIT.HTM";
		if (!isFileExist(filepath)) {
			cout << "ERR: Cannot access microbit driver!" << endl;
			break;
		}

		// 3. check if .hex exist
		if (!isFileExist(filepath_hex)) {
			cout << "ERR: Cannot find .hex file!" << endl;
			break;
		}

		// 4. copy .hex into mbed device
		cout << "uploading..." << endl;
		cmd = "copy \"" + filepath_hex;
		cmd.append("\" ");
		cmd.append(disk_caption);
		cout << cmd << endl;
		system(cmd.c_str());

		cout << "upload finish" << endl;
	} while (0);
}

int main(int argc, char *argv[]) {
	//list_logical_drives();
	time_t from_seconds = 0;
	while(1) {
		from_seconds = dir(".", from_seconds);
		Sleep(100);
	}
	return 0;
}
